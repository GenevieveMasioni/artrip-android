package com.example.pjs4_app;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class OnBoardingViewerPagerAdapter extends PagerAdapter {

    Context c;
    List<ScreenItem> items;

    public OnBoardingViewerPagerAdapter(Context c, List<ScreenItem> items) {
        this.c = c;
        this.items = items;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater = (LayoutInflater) c.getSystemService(c.LAYOUT_INFLATER_SERVICE);
        View layoutScreen = inflater.inflate(R.layout.layout_screen, null);

        ImageView imgSlide = layoutScreen.findViewById(R.id.imageScreen);
        TextView title = layoutScreen.findViewById(R.id.screenTitle);
        TextView description = layoutScreen.findViewById(R.id.screenContent);

        imgSlide.setImageResource(items.get(position).getScreenimg());
        title.setText(items.get(position).getTitle());
        description.setText(items.get(position).getDescription());

        container.addView(layoutScreen);

        return layoutScreen;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == o;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

        container.removeView((View) object);
    }
}
