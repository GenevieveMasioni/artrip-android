package com.example.pjs4_app.artripClasses;

public class Artist extends Object {
    String alias;

    /**
     * Required empty constructor
     */
    public Artist(){
    }

    /**
     * Required constructor
     */
    public Artist(String alias){
        this.alias = alias;
    }
}
