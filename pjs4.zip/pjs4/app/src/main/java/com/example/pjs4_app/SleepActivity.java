package com.example.pjs4_app;



import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class SleepActivity extends AppCompatActivity {
    private String file_path =  Environment.getExternalStorageDirectory().getAbsolutePath()
            +"/Artrip";
    private TextView t;
    private List<StorageReference> items;
    private ArrayList<String> maCollection; // list of unlocked artwork titles for grid view
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    private StorageReference storageReference = storage.getReference();
    private File[] files;

    /**
     * Creates the activity, displays it and sets the attributes
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep);

        File repertoire = new File(file_path);
        items = new ArrayList<>();
        maCollection = new ArrayList<>();
        files = repertoire.listFiles();
        GridView gridview = findViewById(R.id.gridview);
        if (files.length == 0)
            t.setText("Aucune Photo");

        /**
         * Gets all the images of the ArTrip directory
         */
        for (int i = 0; i < files.length; i++) {
            if (files[i].length() != 0) {
                String[] artworkName = files[i].getName().split("\\.");
                String a = artworkName[0];
                maCollection.add(a);
                items.add(storageReference.child("imagesPrincipalesOeuvres/" + a + ".jpg"));
            }
        }

        CustomAdapter customAdapter = new CustomAdapter(SleepActivity.this, items);
        gridview.setAdapter(customAdapter);

        /**
         * On image clicked displays the associated card
         */
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(getApplicationContext(), ArtistCardActivity.class);
                i.putExtra("nomOeuvre", maCollection.get(position));
                i.putExtra("bundleSieste", true);
                startActivity(i);
            }
        });
    }

    /**
     * Returns to the previous activity
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), MainMenuActivity.class));
    }
}
