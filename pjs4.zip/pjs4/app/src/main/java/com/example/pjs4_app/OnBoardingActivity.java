package com.example.pjs4_app;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class OnBoardingActivity extends AppCompatActivity {

    private ViewPager screenPager;
    private OnBoardingViewerPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_boarding);

        List<ScreenItem> items = new ArrayList<>();
        items.add(new ScreenItem("I am slide 1", "lorem ij,doejf", R.drawable.logo_light));
        items.add(new ScreenItem("I am slide 2", "lorem ij,doejf", R.drawable.logo_light));
        items.add(new ScreenItem("I am slide 3", "lorem ij,doejf", R.drawable.logo_light));

        screenPager = findViewById(R.id.screenPager);
        adapter = new OnBoardingViewerPagerAdapter(this, items);
        screenPager.setAdapter(adapter);
    }
}
